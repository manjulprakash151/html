$(document).ready(function(){
    //mobile menu
    $('.mob-menu').click(function(){
        $(this).toggleClass('active');
        $('.nav-wrapper').slideToggle();
    });
    $('.slider-wrapper').slick({
        mobileFirst:true,
        arrows: true,
        dots: true,
        responsive: [
          {
            breakpoint: 767,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1,
            }
        }
        ]
    });
});
$(document).ready(function(){
    //accordion
    $( ".accordion").accordion();
});
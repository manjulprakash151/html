$(document).ready(function(){
   $('.mob-menu').click(function(){
       $(this).toggleClass('active');{
           $('.nav-wrapper').slideToggle();
       }
   })
})
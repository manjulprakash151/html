$(document).ready(function(){
    $('.mob-menu').click(function(){
        $(this).toggleClass('active');
        $('.nav-wrapper').slideToggle();
    });
    $(".accordion .accordion-heading").on('click', function(){
        $(this).siblings(".accordion-body").slideToggle();
       $(this).parents().siblings('.accordion').children(".accordion-body").slideUp();
   });
});
